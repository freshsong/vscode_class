//let a = 10, b = 20, m=30, n=40;    //쉼표로 한번에 선언도 가능
//let result;

//result = a > b ? "noscript" : "javascript"; //javascript
//result = a < b ? "noscript" : "javascript"; //noscript
//console.log(result);


let youkey = 320;
let youweight = 112;

let bmi = (youkey - 100) * 0.9;
youweight = youkey > bmi ? "돼지" : "딱좋아";
console.log(youweight);

