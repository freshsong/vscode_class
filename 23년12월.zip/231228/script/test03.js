
// 증감연산자
/*
let num1 = 10;
let num2 = 20;
let result;

num1--;
console.log(num1);                 // 9

num1++;
console.log(num1);                 // 10

result = num2++;       
console.log(result);               // 20
console.log("result : " + result); // result : 20
console.log("num2 : " + num2);     // num2 : 21

result = ++num2;       
console.log(result);               // 22
console.log("result : " + result); // result : 22
console.log("num2 : " + num2);     // num2 : 22

*/

// 비교연산자
const k = 10;     //숫자
const m = "10";   //문자

console.log(k==m);  //true
console.log(k===m); //false

// 비교연산자 예제
const a = 10;
const b = 20;
const c = 10;
const d = "20";
let result;

result = a > b;
console.log(result); //false

result = a < b;
console.log(result); //true

result = a <= b;
console.log(result); //true

result = b === d;
console.log(result); //false

result = a != b;
console.log(result); //true

result = b !== d;
console.log(result); //true