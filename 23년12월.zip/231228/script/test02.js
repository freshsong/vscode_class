let num1 = 10;
let num2 = 3;

num1 += num2;               //10 + 3
console.log(num1, "<br>");  //13


num1 -= num2;               //10 - 3
console.log(num1, "<br>");  //10

num1 *= num2;               //10 * 3
console.log(num1, "<br>");  //30

num1 %= num2;               //10 / 3
console.log(num1);          //0