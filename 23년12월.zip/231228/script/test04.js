let a = 10, b = 20, m=30, n=40;    //쉼표로 한번에 선언도 가능
let result;

// || or : 둘 중 하나 이상 참이면 참, 아니면 거짓
result = a > b || b >= m || m > n; //f || f || f
console.log(result);               //false

result = a < b || b >= m || m <= n; // t || f || f
console.log(result);               //true

// && and : 둘 다 참이어야 참
result = a <= b && b >= m && m <= n; // t && f && t
console.log(result);                 //false

result = a <= b && b <= m && m >= n; // t && t && f
console.log(result);                 //false

// ! not : 반대값 반환
result = !(a > b);   //false
console.log(result); //false반대값 true