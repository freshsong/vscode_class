console.log("Hello JavaScript");
console.log("Hello JavaScript");
console.log("Hello JavaScript");
console.log("Hello JavaScript");
console.log("Hello JavaScript");
//console.log("Hello JavaScript"); //한줄주석, 부가설명 추가할때, 실행안됨
/*
여러줄 주석으로 이역시 표시 안됨
*/  