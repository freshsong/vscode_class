const num = 300;
if(num > 250){
    console.log("250보다 큰 수 입니다.");
} 