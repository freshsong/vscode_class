//숫자
var intNum = 10;
var floatNum = 0.1;

console.log(intNum, floatNum);


//문자
var str01 = "문자열";
var str02 = '작은따옴표로 만든 문자열';
var str03 = '10';
var str04 = "철수가 \"말했다.\" \'바보\'";
var str05 = '10.22321';

console.log(str04);

//불린 (참거짓)
//컴퓨터는 1, 0 으로 되어있는 언어.
//1 true , 0 false
//있는건 true 없는건 false

var boovar = 1;
var boolvar = true;
console.log(boovar);

// ==같다 ===타입까지같다
var emptyVar;
console.log(emptyVar);

var nullVar = null;
var nullVar2 = "";
console.log(typeof(str03));
console.log(typeof(str02));



//변수를 만드는 법 (다른 언어도 이것과 대부분 똑같)
/*
    1. 첫 글자로 문자, $표시, _(언더바) 만 사용 가능하다. 특수문자는 두가지만 사용가넝.
    2. 중간 또는 끝의 글자는 문자, $, _, 숫자 사용 가능하다.
    3. 변수명은 대소문자를 구분해라. (대소문자 미구분시 전혀 다른변수가 됨)
    4. 변수명을 지을때는 가능하면 변수의 의미를 생각해서 짓는다.
    5. 변수를 복합 단어로 지을때는 두가지 방법이 있다
        5-1) 스네이크 표기법 : I am tom ==> i_am_tom
        5-2) 낙타 표기법 : I am tom ==> iAmTom
*/


//변수를 선언할 때는 var을 앞에 써준다.
//es6에 와서 == 변수 선언하는게 늘어났다.
//var : 한번 선언된거 다시선언? 된다. 새로 값 앉힘. 
//let : 한번 선언된거 다시선언? 에러.
//const : 상수만 가능. 한번 선언하면 새로 값 앉힘 안됨.

var num = 10;
var num = 22;

const pie = 3.14;
//pie = 3.1123; => error
console.log(pie);


