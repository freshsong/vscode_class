console.log("Hello JavaScript");

var box = 100;
box = 30;
console.log(box);         //30 출력

var nums = "1000";
console.log(typeof nums); //string 출력

var num = Number(nums);
console.log(typeof num);  //number 출력
//Boolean (참, 거짓)
var s = 0;
console.log(Boolean(s));  //false 출력

var s = "";
console.log(Boolean(s));  //false 출력 (빈값)

var s = null;
console.log(Boolean(s));  //false 출력 (없는값)

var s = undefined;
console.log(Boolean(s));  //false 출력 (지정되지 않은 값)

var s = "홍길동";
console.log(Boolean(s));  //true 출력


