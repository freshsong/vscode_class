//////////////////////////////////////////////////////////////////////////////////
//다시 선언할 수 있는 선언문
//var
/*var num1 = 15;
var num2 = 20;
var result;
result = num1 + num2;  //문자열에서도 사용 가능
console.log(result);  //35 출력

result = num2 - num1;
console.log(result);  //5 출력

result = num1 * num2;
console.log(result);  //300

result = num1 / num2;
console.log(result);  //0.75

result = num1 % num2; 
console.log(result);  //15 나머지

var str1 = "학교종이";
var str2 = "땡땡떙";
var str3 = 12323;
var str4 = "어서 모이자"
result = str1 + str2 + str3 + str4; //문자열+숫자열 결합출력도 가능하다
console.log(result);
*/
////////////////////////////////////////////////////////////////////////////////////
//다시 선언할 수 없는 선언문(중복선언 금지)
//let
/*
let num1 = 10;
let num2 = "20";
let result = num1 + num2;
console.log(result);   //1020 출력 ()
console.log(result, typeof result); //1020 string 출력 (숫자+문자 == 문자)
*/
let numm1 = 10;
let numm2 = 20;
let numm3 = "30";

let result1 = numm1 + numm2 + numm3; //3030
let result2 = numm1 + numm2 + Number(numm3); //60
let result3 = numm1 + numm3 + numm2; //103020

console.log(result1, result2, result3);


/*
    html 태그에
        변수 1 : do it
        변수 2 : javascript
        합쳐서 출력

        변수1 : "100"
        변수2 : 200
        합쳐서 출력
*/

